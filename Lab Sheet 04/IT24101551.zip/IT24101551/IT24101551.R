## Exercise
getwd()
setwd('C:\\Users\\IT24101551\\Desktop\\IT24101551')


## 1. Import the dataset (’Exercise.txt’) 
branch_data <- read.csv("Exercise.txt", header = TRUE)
print(branch_data)

## 2.	Identify the variable type and scale of measurement for each variable. 
identify_scale <- function(var) {
  if (is.factor(var)) {
    return("Categorical (Nominal)")
  } else if (is.numeric(var)) {
    if (length(unique(var)) > 1 && !any(is.na(var))) {
      return("Numeric (Ratio)")
    } else {
      return("Numeric (Interval)")
    }
  } else {
    return("Unknown")
  }
}

for (col in names(branch_data)) {
  print(paste(col, "->", identify_scale(branch_data[[col]])))
}


## 3.	Obtain boxplot for sales and interpret the shape of the sales distribution. 
boxplot(branch_data$Sales_X1,
        main = "Boxplot of Sales",
        ylab = "Sales",
        col = "lightblue")

## 4. Calculate the five number summary and IQR for advertising variable. 
print("Five-Number Summary for Advertising:\n")
print(summary(branch_data$Advertising_X2))

print("IQR for Advertising:\n")
print(IQR(branch_data$Advertising_X2))


## 5.	Write an R function to find the outliers in a numeric vector and check for outliers in years variables.
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25, na.rm = "True")
  Q3 <- quantile(x, 0.75, na.rm = "True")
  IQR_val <- Q3 - Q1
  lower_bound <- Q1 - 1.5 * IQR_val
  upper_bound <- Q3 + 1.5 * IQR_val
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}

years_outliers <- find_outliers(branch_data$Years_X3)
print("Outliers in Years variable:\n")
print(years_outliers)

